本次毕设的所有实验均在Google Colab(需翻墙)上使用购买的远程GPU运行，training文件夹为移植后可在离线终端训练的版本。
运行本实验需要安装的module及版本：
torch 1.11.0
torchvision 0.12.0
numpy  1.21.0

Training文件夹包含的文件：
1.pythae：模型训练的配置、数据预处理、模型、训练流程、采样器，在训练时会被调用。
2.training.py:执行训练的文件。
3.data：三个预处理后的数据集，供训练时直接调用。
4.generate.py:模型训练完成后，执行该文件可进行图像生成。（执行前需先进入该文件按照注释修改参数）
5.configs：存储模型训练的配置文件，训练模型前需根据训练的数据集对其内容进行覆盖：
	如训练mnist，则用configs_mnist文件夹下文件覆盖configs下文件；
	如训练cifar10，则用configs_cifar10文件夹下文件覆盖configs下文件；
	如训练celeba，则用configs_celeba文件夹下文件覆盖configs下文件；
6.my_models_on_mnist（cifar10/celeba）:用三个数据集训练好的模型分别存储在这三个文件夹下；

经测试，在16G内存且无GPU的终端，训练mnist数据集需要8小时，cifar10和celeba数据集超过12小时。


可在终端利用cd命令training进入文件夹路径，通过以下指令执行模型训练：

python training.py --dataset mnist --model_name vae --model_config 'configs/vae_config.json' --training_config 'configs/base_training_config.json'

可选参数：
--dataset mnist/cifar10/celeba
--model_name ae/vae
--model_config 'configs/vae_config.json'（该参数可省略，如修改vae模型设置，可使用visual studio打开vae_config.json文件来修改）
--training_config 'configs/base_training_config.json'（该参数可省略，如修改训练设置，可使用visual studio打开base_training_config.json文件来修改）

