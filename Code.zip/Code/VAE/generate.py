import os
from pythae.models import VAE, VAEConfig
from pythae.trainers import BaseTrainerConfig
from pythae.pipelines.training import TrainingPipeline
from pythae.models.nn.benchmarks.mnist import Encoder_VAE_MNIST, Decoder_AE_MNIST
from pythae.models.nn.benchmarks.cifar import Encoder_VAE_CIFAR, Decoder_AE_CIFAR
from pythae.models.nn.benchmarks.celeba import Encoder_VAE_CELEBA, Decoder_AE_CELEBA

#此处需要修改最终模型存储文件名称，即修改为“my_models_on_mnist”、“my_models_on_cifar10”和“my_models_on_celeba”
last_training = sorted(os.listdir('my_models_on_celeba'))[-1]
#此处需要根据数据集进行调整
trained_model = VAE.load_from_folder(os.path.join('my_models_on_celeba', last_training, 'final_model'))
#trained_model = VAE.load_from_folder(os.path.join('my_models_on_mnist', last_training, 'final_model'))
#trained_model = VAE.load_from_folder(os.path.join('my_models_on_cifar10', last_training, 'final_model'))



import torch
import torchvision.datasets as datasets
from torchvision import transforms
import numpy as np

#prepare train datasets
mnist_trainset = datasets.MNIST(root='../../data', train=True, download=True, transform=None)
train_dataset = mnist_trainset.data[:-10000].reshape(-1, 1, 28, 28) / 255.
cifar_trainset = datasets.CIFAR10(root='../../data', train=True, download=True, transform=None)
train_dataset = cifar_trainset.data[np.array(cifar_trainset.targets)==1][0:5000]
train_dataset=torch.from_numpy(train_dataset).permute(0,3,1,2)/255.

#此处路径应修改为celeba数据集的"train_data.npz"所在目录
celeba_trainset=np.load('.../training/datasets/celeba/train_data.npz')
train_dataset=celeba_trainset['data']
train_dataset=torch.from_numpy(train_dataset).permute(0,3,1,2)/255.

import matplotlib.pyplot as plt
from pythae.samplers import GaussianMixtureSampler, GaussianMixtureSamplerConfig
from pythae.samplers import TwoStageVAESampler, TwoStageVAESamplerConfig
from pythae.samplers import IAFSampler, IAFSamplerConfig
from pythae.samplers import MAFSampler, MAFSamplerConfig


# set up GMM sampler config
gmm_sampler_config = GaussianMixtureSamplerConfig(
    n_components=10
)

# create gmm sampler
gmm_sampler = GaussianMixtureSampler(
    sampler_config=gmm_sampler_config,
    model=trained_model
)

# fit the sampler
gmm_sampler.fit(train_dataset)

# sample
gen_data = gmm_sampler.sample(
    num_samples=25
)

# show results with gmm sampler(mnist)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(10, 10))

for i in range(5):
    for j in range(5):
        axes[i][j].imshow(gen_data[i*5 +j].cpu().squeeze(0), cmap='gray')
        axes[i][j].axis('off')
plt.tight_layout(pad=0.)

# show results with gmm sampler
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(10, 10))

for i in range(5):
    for j in range(5):
        # axes[i][j].imshow(gen_data[i*5 +j].cpu().squeeze(0), cmap='gray')
        #training set is cifar10 or celeba
        toPIL=transforms.ToPILImage()
        img=toPIL(gen_data[i*5+j])
        axes[i][j].imshow(img)
        #axes[i][j].imshow(gen_data[i*5 +j].permute(1,2,0))
        axes[i][j].axis('off')
plt.tight_layout(pad=0.)



# set up twostagevae config
twostagevae_sampler_config = TwoStageVAESamplerConfig(
)

# create  sampler
twostagevae_sampler = TwoStageVAESampler(
    sampler_config=twostagevae_sampler_config,
    model=trained_model
)

# fit the sampler
twostagevae_sampler.fit(train_dataset)


# sample
gen_data = twostagevae_sampler.sample(
    num_samples=1000
)

# show results with twostage sampler(mnist)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(10, 10))

for i in range(5):
    for j in range(5):
        axes[i][j].imshow(gen_data[i*5 +j].cpu().squeeze(0), cmap='gray')
        axes[i][j].axis('off')
plt.tight_layout(pad=0.)

# show results with twostage sampler(celeba)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(5,5))
k=0
for i in range(5):
    for j in range(5):
        #axes[i][j].imshow(gen_data[i*5 +j].cpu().permute(1,2,0))
        toPIL=transforms.ToPILImage()
        #img=toPIL(gen_data[k])
        img=toPIL(gen_data[i*5+j])
        axes[i][j].imshow(img)
        k=k+1
        axes[i][j].axis('off')
plt.tight_layout(pad=0.5)



# set up MAFSampler config
maf_sampler_config = MAFSamplerConfig(
)

# create  sampler
maf_sampler = MAFSampler(
    sampler_config=maf_sampler_config,
    model=trained_model
)

# fit the sampler
maf_sampler.fit(train_dataset)

# sample
gen_data = maf_sampler.sample(
    num_samples=1000
)

# show results with maf sampler(mnist)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(10, 10))

for i in range(5):
    for j in range(5):
        axes[i][j].imshow(gen_data[i*5 +j].cpu().squeeze(0), cmap='gray')
        axes[i][j].axis('off')
plt.tight_layout(pad=0.)

# show results with maf sampler(celeba)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(5,5))
k=0
for i in range(5):
    for j in range(5):
        #axes[i][j].imshow(gen_data[i*5 +j].cpu().permute(1,2,0))
        toPIL=transforms.ToPILImage()
        #img=toPIL(gen_data[k])
        img=toPIL(gen_data[i*5+j])
        axes[i][j].imshow(img)
        k=k+1
        axes[i][j].axis('off')
plt.tight_layout(pad=0.5)




# set up IAFSampler config
iaf_sampler_config = IAFSamplerConfig(
)

# create  sampler
iaf_sampler = IAFSampler(
    sampler_config=iaf_sampler_config,
    model=trained_model
)

# fit the sampler
iaf_sampler.fit(train_dataset)

# sample
gen_data = iaf_sampler.sample(
    num_samples=1000
)

# show results with iaf sampler(mnist)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(10, 10))

for i in range(5):
    for j in range(5):
        axes[i][j].imshow(gen_data[i*5 +j].cpu().squeeze(0), cmap='gray')
        axes[i][j].axis('off')
plt.tight_layout(pad=0.)

# show results with iaf sampler(celeba)
fig, axes = plt.subplots(nrows=5, ncols=5, figsize=(5,5))
k=0
for i in range(5):
    for j in range(5):
        #axes[i][j].imshow(gen_data[i*5 +j].cpu().permute(1,2,0))
        toPIL=transforms.ToPILImage()
        #img=toPIL(gen_data[k])
        img=toPIL(gen_data[i*5+j])
        axes[i][j].imshow(img)
        k=k+10
        axes[i][j].axis('off')
plt.tight_layout(pad=0.3)
input("generate success?")