"""
In this model are gathered some predefined neural nets architectures that may be used on 
benchmark datasets such as MNIST, CIFAR or CELEBA
"""
